#!/bin/bash

set -e

cd tests
./test-runner.exe -l -Q -p1 0000
